export interface Dip {
  id: string;
  type: string;
  name: string;
  description: string;
  price: number;
}

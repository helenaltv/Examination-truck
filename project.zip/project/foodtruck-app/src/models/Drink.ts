export interface Drink {
  id: string;
  type: string;
  name: string;
  description: string;
  price: number;
}

import { MenuItem } from "./MenuItem";

export interface OrderBody {
  items: MenuItem[];
}

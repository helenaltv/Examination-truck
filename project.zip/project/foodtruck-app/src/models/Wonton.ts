export interface Wonton {
  id: string;
  type: string;
  name: string;
  description: string;
  price: number;
  ingredients: string[];
}

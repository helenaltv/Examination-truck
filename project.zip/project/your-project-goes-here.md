Install your React app here.
